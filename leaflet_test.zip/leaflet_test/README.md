# Container (glass, old clothes) Moers

## Development
### Install Dependencies
``
$ npm install
``

### Start Webserver
``
$ npm start
``

This would start a webserver and open this link in your browser: http://localhost:10001/
