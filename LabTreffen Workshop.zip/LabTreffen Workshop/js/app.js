$(document).ready(function() {
    $.getJSON( "containerstandorte.json", function( data ) {
        create_map(data)
    });
});

function create_map(json_data) {
	// Hier alles wichtige einfügen!
}